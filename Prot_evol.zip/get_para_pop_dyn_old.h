int Get_para(int argc, char **argv, char *file_seq, int *N_pop,
	     float *sel_coeff, float *freq_nuc, float *trans_ratio,
	     float *IT_MAX, float *thr_a, float *thr_E,
	     unsigned long *iran, float *s0,
	     char *file_ene, char *file_str, char *file_code);
