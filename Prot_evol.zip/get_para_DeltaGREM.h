int Get_para(int argc, char **argv,
	     char ***file_pdb, char chain[], char *file_str,
	     float *TEMP, float *sU1, float *sC0, float *sC1, int *REM,
	     char **file_ali, char **file_mut, char *dir_out);
