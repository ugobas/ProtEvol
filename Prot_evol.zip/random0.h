int InitRan0(unsigned long iseed);
float RandomVar0();
