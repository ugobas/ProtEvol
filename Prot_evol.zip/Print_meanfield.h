int Print_profiles(float **P_MF_ia, float *P_mut_a, double DG_ave,
		   float Lambda, short *aa_seq, int L, char *name_file,
		   char *tag);
int Print_subst_rate(float **P_MF_ia, float *P_mut_a,
		     float *P_cod, float **Q_cod,
		     float tt_ratio, short *aa_seq,
		     int **Cnat, char *sec_str, int L,
		     char *name_file, float TWONUC);
int Print_exchange(float **P_MF_ia, float *P_mut_a,
		   float *P_cod, float **Q_cod,
		   float tt_ratio, float TWONUC,
		   short *aa_seq, struct residue *res, int **Cnat,
		   char *sec_str, int L, char *nameout, char *tag,
		   int FORMAT, char EXCHANGE,char *MATRIX, int PRINT_E);
int Print_profile_evo(char *name, double **P_ia, short *aa_seq, int L,
		      double DG_ave, long it_sum);
