#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "REM.h"
#include "allocate.h"
#include "meanfield.h"
#include "optimization.h"
#include "codes.h"
#include "gen_code.h"
#define GET_DG_OPT 0

/*
  struct MF_results{
  float DG;
  float Tf;
  float h;
  float Lambda;
  float lik;
  float KL;
  float entropy;
  float rate;
};
 */

void Print_test(char *name_file, int L, struct MF_results res,
		struct REM E_wt, char *what, int open);
void Print_fitness(char *name_file, int L, float *mut_par,
		   struct MF_results res, struct REM E_wt, char *model);
float Find_max(float *y, float *x, int n, float MIN, float MAX);
static void Copy_vars(struct MF_results *store, struct MF_results *tmp);
static void Optimize_DG(struct MF_results *DG_opt,
			float **P_DG_opt_ia, float *dDG_opt,
			float *P_mut_a, float **P_MF_ia, int L,
			float *Lambda_k, float *y, int N_Lambda,
			float DG_OPT, int **C_nat, int *i_sec,
			short *aa_seq, struct REM E_wt);

int Fixed_Lambda(double *DG_ave, float **P_MF_ia, float *P_mut_a,
		 int **C_nat, int *i_sec, short *aa_seq,
		 struct REM E_wt, float Lambda, char *name_file)
{
  int L=E_wt.L;
  struct MF_results nat_opt, all_opt; 

  printf("### Mean-field computations\n");
  printf("Mean field distribution, native state Lambda=%.3f\n", Lambda);
  meanfield(P_MF_ia, &nat_opt, P_mut_a, NULL,
	    C_nat, i_sec, L, Lambda, E_wt, 0); // Only native state
  nat_opt.lik=Compute_lik(P_MF_ia, L, aa_seq);
  Print_test(name_file, L, nat_opt, E_wt, "nat", 0);

  printf("Mean field distribution, native and misfolding Lambda=%.3f\n",
	 Lambda);
  meanfield(P_MF_ia, &all_opt, P_mut_a, NULL,
	    C_nat, i_sec, L, Lambda, E_wt, 1); // Also misfolded state
  all_opt.lik=Compute_lik(P_MF_ia, L, aa_seq);
  Print_test(name_file, L, all_opt, E_wt, "all", 0);
  *DG_ave=all_opt.DG;
  Print_fitness(name_file, L, mut_par, all_opt, E_wt, "all");
  return(0);
}

int Optimize_Lambda(float *LAMBDA, double *DG_ave,
		    float **P_MF_ia, float *P_mut_a,
		    int **C_nat, int *i_sec, short *aa_seq,
		    struct REM E_wt, float DG_OPT,
		    int GET_FREQ, char *MODEL, char *name_file,
		    FILE *file_summary)
{
  int L=E_wt.L;
  int N_Lambda=16; //12
  float Lambda_step=0.05;
  //float Lambda_fit=1.1-0.12*log((float)L);
  float Lambda_ini=0.0; //0.45 //Lambda_fit-3*Lambda_step;

  float Lambda, Lambda_end, Lambda_k[N_Lambda];
  float lik_nat[N_Lambda], lik_all[N_Lambda];
  struct MF_results nat_res[N_Lambda], all_res[N_Lambda];
  struct MF_results nat_opt, all_opt, DG_opt; 
  int a, k, i;

  // Native meanfield
  Lambda=Lambda_ini;
  float **P_nat_opt_ia=Allocate_mat2_f(L, 20);
  printf("\n### Mean-field computations\n");
  struct MF_results *res=nat_res;
  for(k=0; k<N_Lambda; k++){
    printf("Mean field distribution, native state Lambda=%.3f\n", Lambda);
    res->conv=meanfield(P_MF_ia, res, P_mut_a, P_MF_ia,
			C_nat, i_sec, L, Lambda, E_wt, 0);
    res->lik=Compute_lik(P_MF_ia, L, aa_seq);
    res->h=Hydro_ave(P_MF_ia, hydro, L);
    if((k==0)||(res->lik > nat_opt.lik)){
      Copy_P(P_nat_opt_ia, P_MF_ia, L, 20);
      Copy_vars(&nat_opt, res);
    }
    Lambda_k[k]=Lambda; lik_nat[k]=res->lik;
    Lambda+=Lambda_step; res++;
  }
  Lambda_end=Lambda_k[N_Lambda-1]+0.2;

  // Native+misfolding meanfield
  Lambda=Lambda_ini; float dDG_opt=1000, dDG;
  float **P_all_opt_ia=Allocate_mat2_f(L, 20);
  float **P_DG_opt_ia=Allocate_mat2_f(L, 20);
  for(i=0; i<L; i++)for(a=0; a<20; a++)P_MF_ia[i][a]=P_mut_a[a];
  res=all_res;
  for(k=0; k<N_Lambda; k++){
    printf("Mean field distribution, native and misfolding Lambda=%.3f\n",
	   Lambda);
    res->conv=meanfield(P_MF_ia, res, P_mut_a, P_MF_ia,
			C_nat, i_sec, L, Lambda, E_wt, 1);
    res->lik=Compute_lik(P_MF_ia, L, aa_seq);
    res->h=Hydro_ave(P_MF_ia, hydro, L);
    Print_fitness(name_file, L, mut_par, *res, E_wt, "all");
    if((k==0)||(res->lik > all_opt.lik)){
      Copy_P(P_all_opt_ia, P_MF_ia, L, 20);
      Copy_vars(&all_opt, res);
    }
    dDG=fabs(res->DG-DG_OPT);
    if((k==0)||(dDG < dDG_opt)){
      dDG_opt=dDG;
      Copy_P(P_DG_opt_ia, P_MF_ia, L, 20);
      Copy_vars(&DG_opt, res);
    }
    Lambda_k[k]=Lambda; lik_all[k]=res->lik;
    Lambda+=Lambda_step; res++;
  }

  char name[500]; sprintf(name, "%s_likelihood.dat", name_file);
  FILE *file_out=fopen(name, "w");
  fprintf(file_out, "# T=%.3f SU= %.2f SC= %.2f\n",
	  E_wt.T,  E_wt.S_U,  E_wt.S_C);
  if(SEC_STR){fprintf(file_out, "# Sec.str. used, factor= %.3f\n",SEC_STR);}
  else{fprintf(file_out, "# Sec.str. not used\n");}
  char sfreq[200];
  if(GET_FREQ==0){
    sprintf(sfreq, "# Mutation frequencies (nucs) obtained from input\n");
  }else if (GET_FREQ==1){
    sprintf(sfreq, "# Mutation frequencies (nucs) obtained from fit\n");
  }else if (GET_FREQ==2){
    sprintf(sfreq, "# Mutation frequencies (nucs) obtained from fit\n");
  }
  fprintf(file_out, "%s", sfreq);
  fprintf(file_out, "# Optimizing Lambda L=%d\n", L);
  /*fprintf(file_out, "# Mutation model: DG= %.2f lik= %.4f h= %.3f Tf= %.2f\n",
    mut_res.DG, mut_res.lik, mut_res.h, mut_res.Tf);*/
  fprintf(file_out, "# Lambda DG_all DG_nat lik_all lik_nat ");
  fprintf(file_out, " h_all h_nat");
  fprintf(file_out, " Tf_all Tf_nat");
  fprintf(file_out, " Conv_all Conv_nat\n");
  struct MF_results *all=all_res, *nat=nat_res;
  for(k=0; k<N_Lambda; k++){
    fprintf(file_out, "%.2f ", Lambda_k[k]);
    fprintf(file_out, "%6.1f ", all->DG);
    fprintf(file_out, "%6.1f ", nat->DG);
    fprintf(file_out, "%.4f ", all->lik);
    fprintf(file_out, "%.4f ", nat->lik);
    fprintf(file_out, "%.3f ", all->h);
    fprintf(file_out, "%.3f ", nat->h);
    fprintf(file_out, "%.2f ", all->Tf);
    fprintf(file_out, "%.2f ", nat->Tf);
    fprintf(file_out, "%d ", all->conv);
    fprintf(file_out, "%d\n", nat->conv);
    all++; nat++;
  }
  // Wild type sequence
  double h_wt=0; for(i=0; i<L; i++)h_wt+=hydro[aa_seq[i]]; h_wt/=L;
  fprintf(file_out, "# DG(PDB_sequence)= %.2f h_wt= %.3f\n",
	  E_wt.DeltaG, h_wt);

  // Maximum likelihood native model
  struct MF_results tmp;
  Lambda=Find_max(lik_nat, Lambda_k, N_Lambda, Lambda_ini/2, Lambda_end);
  meanfield(P_MF_ia, &tmp, P_mut_a, P_MF_ia,
	    C_nat, i_sec, L, Lambda, E_wt, 0);
  tmp.lik=Compute_lik(P_MF_ia, L, aa_seq);
  if(tmp.lik > nat_opt.lik){
    tmp.h=Hydro_ave(P_MF_ia, hydro, L);
    Copy_P(P_nat_opt_ia, P_MF_ia, L, 20);
    Copy_vars(&nat_opt, &tmp);
  }
  printf("Maximum likelihood native model: %.2f optimal Lambda=%.3f\n",
	 nat_opt.lik, nat_opt.Lambda);
  fprintf(file_out, "# Max_likelihood_meanfield_nat: ");
  fprintf(file_out, "Lambda= %.3f lik= %.4f DG= %.1f h=%.3f\n",
	  nat_opt.Lambda, nat_opt.lik, nat_opt.DG, nat_opt.h);

  // Maximum likelihood complete model	 
  Lambda=Find_max(lik_all, Lambda_k, N_Lambda, Lambda_ini/2, Lambda_end);
  meanfield(P_MF_ia, &tmp, P_mut_a, P_MF_ia,
	    C_nat, i_sec, L, Lambda, E_wt, 1); 
  tmp.lik=Compute_lik(P_MF_ia, L, aa_seq);
  if(tmp.lik > all_opt.lik){
    tmp.h=Hydro_ave(P_MF_ia, hydro, L);
    Copy_P(P_all_opt_ia, P_MF_ia, L, 20);
    Copy_vars(&all_opt, &tmp);
  }
  printf("Maximum likelihood complete model: %.2f optimal Lambda=%.3f\n",
	 all_opt.lik, all_opt.Lambda);
  fprintf(file_out, "# Max_likelihood_meanfield_all: ");
  fprintf(file_out, "Lambda= %.3f lik= %.4f DG= %.1f h=%.3f\n",
	  all_opt.Lambda, all_opt.lik, all_opt.DG, all_opt.h);
  *LAMBDA=all_opt.Lambda;
  Print_fitness(name_file, L, mut_par, all_opt, E_wt, "all");

  if(GET_DG_OPT){
    float y[N_Lambda];
    for(k=0; k<N_Lambda; k++)y[k]=-fabs(all_res[k].DG-DG_OPT); 
    Lambda=Find_max(y, Lambda_k, N_Lambda, Lambda_ini/2, Lambda_end);
    printf("Complete model with DG ~ %.3f optimal Lambda=%.3f\n",
	   DG_OPT, Lambda);
    meanfield(P_MF_ia, &tmp, P_mut_a, P_MF_ia,
	      C_nat, i_sec, L, Lambda, E_wt, 1);
    if(fabs(*DG_ave-DG_OPT) < dDG_opt){
      dDG_opt=fabs(*DG_ave-DG_OPT);
      Copy_P(P_DG_opt_ia, P_MF_ia, L, 20);
      tmp.lik=Compute_lik(P_MF_ia, L, aa_seq);
      tmp.h=Hydro_ave(P_MF_ia, hydro, L);
      Copy_vars(&DG_opt, &tmp);
    }
    // Interpolate quadratically to identify DG_OPT
    Optimize_DG(&DG_opt, P_DG_opt_ia, &dDG_opt, P_mut_a, P_MF_ia, L,
		Lambda_k, y, N_Lambda, DG_OPT, C_nat, i_sec, aa_seq, E_wt);
    fprintf(file_out, "# Optimal_DG_meanfield_all: ");
    fprintf(file_out, "Lambda= %.3f lik= %.4f DG= %.1f h=%.3f\n",
	    DG_opt.Lambda, DG_opt.lik, DG_opt.DG, DG_opt.h);
  }
  printf("### End of mean-field computations\n");
  printf("Writing %s\n", name);
  fclose(file_out);

  Print_results(nat_opt, "nat", file_summary);
  Print_results(all_opt, "all", file_summary);
  if(GET_DG_OPT)Print_results(DG_opt, "DGo", file_summary);

  // Output distribution
  printf("Meanfield model, type %s\n", MODEL);
  if(strcmp(MODEL, "NAT")==0){
    Copy_P(P_MF_ia, P_nat_opt_ia, L, 20); *DG_ave=nat_opt.DG;
  }else if(strcmp(MODEL, "ALL")==0){
    Copy_P(P_MF_ia, P_all_opt_ia, L, 20); *DG_ave=all_opt.DG;
  }else if(strcmp(MODEL, "DG")==0){
    Copy_P(P_MF_ia, P_DG_opt_ia, L, 20); *DG_ave=DG_opt.DG;
  }else{
    printf("ERROR, %s is not an allowed optimization criterion.\n", MODEL);
    printf("Allowed criteria are NAT ALL and DG\n");
    exit(8);
  }

  Empty_matrix_f(P_all_opt_ia, L);
  Empty_matrix_f(P_nat_opt_ia, L);
  Empty_matrix_f(P_DG_opt_ia, L);
  return(0);
}

void Print_results(struct MF_results res, char *what, FILE *file_out)
{
  //Model Lambda likelihood KL DG Tf h
  fprintf(file_out, "%s\t%.2f\t%.3f\t%.3f\t%.1f\t%.2f\t%.3f\n",
	  what, res.Lambda, res.lik, res.KL, res.DG, res.Tf, res.h);
}

void Optimize_DG(struct MF_results *DG_opt, float **P_DG_opt_ia,
		 float *dDG_opt, float *P_mut_a, float **P_MF_ia, int L,
		 float *Lambda_k, float *y, int N_Lambda, float DG_OPT,
		 int **C_nat, int *i_sec, short *aa_seq, struct REM E_wt)
{
  // Iterations to find DG_OPT
  int IT_MAX=4, iter=0, k;
  float L0, L1, L2;
  float y0, y1, y2;
  float Lambda=DG_opt->Lambda,
    Lambda_ini=Lambda_k[0], Lambda_end=Lambda_k[N_Lambda-1]+0.2;
  struct MF_results tmp;
  while( (((DG_opt->DG)>0)||((DG_opt->DG)<2*DG_OPT))&&(iter<IT_MAX)){
    printf("Lambda= %.3f DG= %.2f iter=%d\n", Lambda, DG_opt->DG, iter);
    iter++;
    float yy=-fabs(DG_opt->DG-DG_OPT);
    if(iter==1){
      if(Lambda < Lambda_k[0]){
	L0=Lambda, L1=Lambda_k[0], L2=Lambda_k[1];
	y0=yy; y1=y[0]; y2=y[1];
      }else if(Lambda > Lambda_k[N_Lambda-1]){
	L0=Lambda_k[N_Lambda-2]; L1=Lambda_k[N_Lambda-1]; L2=Lambda;
	y0=y[N_Lambda-2]; y1=y[N_Lambda-1]; y2=yy;
      }else{
	for(k=1; k<N_Lambda; k++)if(Lambda_k[k]>Lambda)break;
	if(k==N_Lambda)k--;
	if((Lambda < Lambda_k[k-1])||(Lambda > Lambda_k[k])){
	  printf("WARNING, badly ordered series of Lambda: %.3f %.3f %.3f\n",
		 Lambda_k[k-1], Lambda, Lambda_k[k]); break;
	}
	L0=Lambda_k[k-1]; L1=Lambda; L2=Lambda_k[k];
	y0=y[k-1]; y1=yy; y2=y[k];
      }
    }else{
      if(Lambda < L0){
	L2=L1; y2=y1; L1=L0; y1=y0; L0=Lambda; y0=yy;
      }else if(Lambda < L1){
	L2=L1; y2=y1; L1=Lambda; y1=yy;
      }else if(Lambda < L2){
	L0=L1; y0=y1; L1=Lambda; y1=yy;
      }else{
	L0=L1; y0=y1; L1=L2; y1=y2; L2=Lambda; y2=yy;
      }
    }
    printf("L0= %.2f L1= %.2f L2= %.2f\n", L0, L1, L2);
    printf("y0= %.2f y1= %.2f y2= %.2f\n", y0, y1, y2);
    
    Lambda =Find_max_quad(L0,L1,L2,y0,y1,y2,Lambda_ini/4,Lambda_end*1.2);
    printf("Performing attempt %d to optimize Lambda, Lambda=%.3f\n",
	   iter+1, Lambda);
    meanfield(P_MF_ia, &tmp, P_mut_a, P_MF_ia,
	      C_nat, i_sec, L, Lambda, E_wt, 1);
    float ddG=-fabs(tmp.DG-DG_OPT);
    if(ddG > *dDG_opt){
      *dDG_opt=ddG;
      Copy_P(P_DG_opt_ia, P_MF_ia, L, 20);
      tmp.lik=Compute_lik(P_MF_ia, L, aa_seq);
      tmp.h=Hydro_ave(P_MF_ia, hydro, L);
      Copy_vars(DG_opt, &tmp);
    }
  }
}

void Print_fitness(char *name_file, int L, float *mut_par,
		   struct MF_results res, struct REM E_wt, char *model)
{
  char name[500]; sprintf(name, "%s_fitness.dat", name_file);
  FILE *file_out=fopen(name, "w");
  double f=1./(1+exp(res.DG)), LL;
  printf("Writing %s\n", name);
  fprintf(file_out, "#Model %s DG_WT= %.3f\n", model, E_wt.DeltaG);
  if(SEC_STR)fprintf(file_out, "#Local interactions used, factor= %.3f\n", SEC_STR);
  fprintf(file_out, "# tt_ratio kCpG mu  TEMP Lambda_eff = ");
  fprintf(file_out, " %.2f %.1f %.4f", mut_par[4], mut_par[5], mut_par[6]);
  fprintf(file_out, "   %.2f ", E_wt.T);
  fprintf(file_out, "   %.3f ", res.Lambda);
  fprintf(file_out, "\n");
  fprintf(file_out, "#len   G C A T  ");
  fprintf(file_out, " DG fitness likelihood PDB Lambda\n");
  fprintf(file_out, "%d   %.3f %.3f %.3f %.3f", L,
	  mut_par[Code_nuc('G')], mut_par[Code_nuc('C')],
	  mut_par[Code_nuc('A')], mut_par[Code_nuc('T')]);
  fprintf(file_out, "   %.2f ", res.DG*E_wt.T);
  fprintf(file_out, "   %.6f ", f);
  fprintf(file_out, "   %.3f ", res.lik);
  name[5]='\0';
  fprintf(file_out, " \"%s\"", name);
  LL=log(res.Lambda*E_wt.T);
  if(f >= 0.5){LL-=res.DG;} // log(Lambda*T/(f(1-f));
  else{LL-=log(0.25);}
  fprintf(file_out, "   %.4g\n", LL);
  fclose(file_out);
}

void Print_test(char *name_file, int L, struct MF_results res,
		struct REM E_wt, char *what, int open)
{
  char name[500]; FILE *file_out;
  sprintf(name, "%s_likelihood.dat", name_file);
  if(open){
    file_out=fopen(name, "w");
    printf("Writing %s\n", name);
    fprintf(file_out, "# Third moment of energy used: ");
    if(E_wt.REM==3){fprintf(file_out,"YES\n");}
    else{fprintf(file_out,"NO\n");}
    fprintf(file_out, "#Model DG/T log_lik/L Lambda= %.2f L=%d\n",
	    res.Lambda, L);
    fprintf(file_out, "DeltaG/T_%s Pairwise= %7.4f\n", what, E_wt.DeltaG);
  }else{
    file_out=fopen(name, "a");
  }
  fprintf(file_out, "%s %7.4f %7.4f\n", what, res.DG, res.lik);
  fclose(file_out);
}

float Find_max(float *y, float *x, int n, float MIN, float MAX)
{
  int i, k=0; float ymax=y[0];
  for(i=1; i<n; i++)if(y[i]>ymax){ymax=y[i]; k=i;}
  if(k==0){
    printf("WARNING, maximum attained at lowest x (x= %.3g max= %.3g)\n",
	   x[k], y[k]); k=1;
  }else if(k==(n-1)){
    printf("WARNING, maximum attained at highest x (x= %.3g max= %.3g)\n",
	   x[k], y[k]); k=n-2;
  }
  
  float x0=Find_max_quad(x[k-1], x[k], x[k+1], y[k-1], y[k], y[k+1],MIN,MAX);
  return(x0);
}

float Hydro_ave(float **P_ia, float *hydro, int L){
  int i, a; double sum=0;
  for(i=0; i<L; i++){
    float *P_a=P_ia[i]; double h=0;
    for(a=0; a<20; a++)h+=P_a[a]*hydro[a]; sum+=h;
  }
  return(sum/L);
}

void Copy_vars(struct MF_results *store, struct MF_results *tmp)
{
  store->DG=tmp->DG; store->lik=tmp->lik; store->Lambda=tmp->Lambda; 
  store->Tf=tmp->Tf;  store->KL=tmp->KL;  store->h=tmp->h;
}

void Compute_P_sel(float *P_sel, float **P_MF_ia, float *P_mut_a, int L){
  int i, a;
  for(a=0; a<20; a++){
    double sum=0;
    for(i=0; i<L; i++)sum+= P_MF_ia[i][a];
    P_sel[a]=sum/(L*P_mut_a[a]);
  }
}

