int Read_secondary_structure(struct residue *res, char *file,
			     char *chain_to_read, int nres);
float **Read_propensity(char *name_in);
extern char SEC_EL[16];
