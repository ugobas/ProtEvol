int Get_pdb(struct protein *prot, struct residue **res,
	    char *file, char *chain, int model);
int Count_models_PDB(char *file_pdb);
