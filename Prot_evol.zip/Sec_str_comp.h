double Compute_E_loc(int *i_sec, short *aa_seq, int L);
void Initialize_E_loc(float T, float SEC_STR);
double Delta_E_loc(int i_sec, short aa_old, short aa_new);
