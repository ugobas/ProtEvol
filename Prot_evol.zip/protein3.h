#define IJ_MIN 4  // Minimum value of |i-j| for contacts 
#define N_PROT_MAX 10000
#define N_PARAM 211
#define N_STR 100

/******************************

 *          Functions         *
 
 ******************************/

extern int Threading(short *, float *, float *, float, float *, int);
extern int Ini_thread(char *, int);

/*****************************

 *         Variables         *
 
 *****************************/

struct contact{
  short res1;
  short res2;
};

struct protein{
  char name[40];
  int length;
  int n_cont;
  short **contact;
  struct contact *cont_list;
  short *aa_seq;
  char *sec_str;
  int *i_sec;
};

struct state{
  short first;
  float energy;
  float overlap;
  float alpha;
  short n_cont;
  short **cont;
  struct protein *prot_ptr;
};

extern struct protein prot[N_PROT_MAX], target;
//extern float **interactions;









