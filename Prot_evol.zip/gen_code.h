//void Compute_exchange_mut(float **exchange, float **rate,
//			  float *P_cod, float **Q_cod);
void Get_mut_par(float *mut_par, float *P_mut, float *P_cod, float **Q_cod,
		 int GET_FREQ, float *num_aa, int L_aa, float *num_dna, 
		 char *name_file, int iter);
void Normalize_distr(float *P, int N);
int Code_codon(char *i_codon, char **codon);
float Weight_codon(char *c, float *f);
float Weight_codon_CpG(char *c, float *f);
int Sum_aa(float *num_aa, char *file_ali);
char coded_aa[64], *codon[64]; 
#define MUTPAR 10
float mut_par[MUTPAR]; // CHANGE_26/05/2014
