#include "protein3.h"
float alpha_REM(short *sequence, float *E_nat, float *zz, int len_nat,
		float *cont_ave, float *cont_dev, int res_mut, int aa_old,
		int mutation);
