//char AA_code[]="AEQDNLGKSVRTPIMFYCWH";
float AA_freq_UniProt[20]={8.25, 6.75, 3.93, 5.45, 4.06, 9.66, 7.07, 5.84, 6.57, 6.86, 5.53, 5.34, 4.70, 5.95, 2.41, 3.86, 2.92, 1.37, 1.08, 2.27};
//Source: http://web.expasy.org/docs/relnotes/relstat.html
