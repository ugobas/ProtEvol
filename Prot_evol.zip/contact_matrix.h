short **Contact_matrix(struct residue *seq, int N_res, int *N_cont,
		       char l_cont, int ij_min);
struct contact *Contact2Contlist(short **contact, int nres, int ncont);
